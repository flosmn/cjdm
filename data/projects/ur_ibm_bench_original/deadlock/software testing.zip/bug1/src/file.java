
/**
 * Created by IntelliJ IDEA.
 * User: liran klein
 * Date: 02/10/2003
 * Time: 10:49:10
 * To change this template use Options | File Templates.
 */
public class file
 {
    private String info;
    public file()
    {
        info="message";
    }
    public file(String str)
    {
        info=str;
    }
    public String getInfo()
    {
        return info;
    }

    public void setInfo(String str )
    {
        info=str;
    }

}
