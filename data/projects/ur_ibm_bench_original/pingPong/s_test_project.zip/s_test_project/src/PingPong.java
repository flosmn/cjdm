

/**
 *@author Golan
 * 17/10/2003
 * 13:48:28
 *@version 1.0
 */


public class PingPong {


    /**
     *
     */
    private int i;


    /**
     *
     */
    public PingPong() {
        i = 0;
    }


    /**
     *
     * @return
     */
    public int getI() {
        return i;
    }


    /**
     *
     * @param i
     */
    public void setI(int i) {
        this.i = i;
    }


}
